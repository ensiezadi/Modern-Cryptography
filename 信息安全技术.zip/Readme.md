# 现代密码学相关算法及实现

- 1:DES 和 TripleDES ，同时使用CBC模式进行预处理；
- 2:AES
- 3:RSA
- 4:SHA-2和SM3
- 5:Hmac + （SHA-2/SM3）
- 6:DES算法的CFB模式；AES算法的CBC模式
- 7:SHA-1算法实现HMAC实验
- 8:RSA算法和快速指数运算
